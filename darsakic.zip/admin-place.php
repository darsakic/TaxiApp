<?php 
include "header.php";
$conn=dbConn();


if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
	$Q = "SELECT * FROM zupanija, korisnik WHERE zupanija.moderator_id = korisnik.korisnik_id";
	$result = executeQ($conn, $Q);

	echo "<div>";
	echo "<table style='padding:2%;'>";
	echo "<caption><h2> Popis korisnika </h2></caption>";
	echo "<thead><tr>
		<th>Županija</th>
		<th>Moderator</th>
		<th>Broj vozila</th>";
	echo "</tr></thead>";
		while ($row = mysqli_fetch_array($result)) {
			$place_id = $row['zupanija_id'];
			$korisnik_id = $row['korisnik_id'];
			echo "<tr>";
			echo "<td>{$row['naziv']}</td>";
           	echo "<td>{$row['ime']} {$row['prezime']}</td>";
           	echo "<td>{$row['broj_vozila']}</td>";
           	echo "<td><a class='link' href='admin-updateplace.php?zupanija=$place_id&korisnik=$korisnik_id'>UREDI</a></td>";
			echo "</tr>";
		}
	echo "</table>";
	 echo "</div>";

}
?>