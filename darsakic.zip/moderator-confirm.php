<?php 
include "header.php";
$conn=dbConn();



if (isset($_POST['submit'])) {
	$reservation_id = $_POST['reservation_id'];
	$car_id = $_POST['car_id'];
    $duration = $_POST['duration'];
    
    $Q = "SELECT datum_vrijeme_polaska FROM rezervacija WHERE rezervacija_id = '$reservation_id' ";;
    $result = executeQ($conn, $Q);
    $row = mysqli_fetch_array($result);
    $date_time_start = $row['datum_vrijeme_polaska'];

    $Q2 = "SELECT DATE_ADD('$date_time_start', INTERVAL $duration MINUTE)";
    $result2 = executeQ($conn, $Q2);
    list($date_time_end) = mysqli_fetch_array($result2);

    $Q4 = "SELECT r.rezervacija_id, v.oznaka, r.vozilo_id, r.datum_vrijeme_polaska, r.datum_vrijeme_dolaska  FROM rezervacija r, vozilo v 
		WHERE (r.datum_vrijeme_polaska BETWEEN '$date_time_start' 
		AND '$date_time_end' 
		OR r.datum_vrijeme_dolaska BETWEEN '$date_time_start' AND  '$date_time_end')
		AND r.vozilo_id = v.vozilo_id AND r.status =  1; ";
		$result4 = executeQ($conn, $Q4);
		$check = False;

		while($row = mysqli_fetch_array($result4)){
			if($row[2] == $car_id){
				$check = True;
			}
		}

		if ($check == False) {
			$Q3 = "UPDATE rezervacija SET datum_vrijeme_dolaska = '$date_time_end', status = '1' WHERE rezervacija_id = '$reservation_id'";
        	$result3 = executeQ($conn, $Q3);
        	$_SESSION['confirm'] = "Rezervacija " . $reservation_id . " uspješna!";

        	if ($_SESSION['user_type'] == 1) {
				header('Location: moderator-request.php');
			}elseif ($_SESSION['user_type'] == 0) {
				header('Location: admin-request.php');
			}
		} else {
			$_SESSION['error'] = "Pogreška: Rezervacija " . $reservation_id . " je neuspjela. Auto je zauzeto drugom vožnjom!";

			if ($_SESSION['user_type'] == 1) {
				header('Location: moderator-request.php');
			}elseif ($_SESSION['user_type'] == 0) {
				header('Location: admin-request.php');
			}
		

		}
        
}

if(isset($_SESSION['username']) && $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
	
    echo '<form method="POST" action="moderator-confirm.php">
    	<input type="hidden" name="reservation_id" value=' . $_GET['rezervacija'] . '>
    	<input type="hidden" name="car_id" value=' . $_GET['vozilo'] . '>
		<table style="padding:2%;">
			<caption><h2>Potvrda vožnje<h2></caption>
		<tbody>
			<tr>
				<td>
					<label for="duration"><strong>Trajanje vožnje(u minutama)</strong></label>
					<input type="number" min="1" max="60" name="duration"/>
				</td>
            </tr>
            
            <tr>
				<td colspan="2" style="text-align:center;">

					<input name="submit" type="submit" value="Potvrdi"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';


}else{
	header('Location:moderator.php');}
	
 ?>
