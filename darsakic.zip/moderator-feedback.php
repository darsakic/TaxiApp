<?php 

include "header.php";
$conn = dbConn();

if (isset($_POST['submit'])) {
	$comment = $_POST['comment'];
	$user_id = $_SESSION['user_id'];
	$reservation_id = $_POST['reservation_id'];
	$Q = "UPDATE rezervacija SET komentar = '$comment' WHERE rezervacija_id = '$reservation_id'";
	executeQ($conn, $Q);

}

if (isset($_SESSION['username']) && $_SESSION['user_type'] == 1) {
	$user_id = $_SESSION['user_id'];
	$Q1 = "SELECT r.komentar, r.adresa_polaska_id, r.adresa_odredista_id, r.datum_vrijeme_polaska, r.datum_vrijeme_dolaska, v.oznaka, a.ulica, r.rezervacija_id FROM adresa a, rezervacija r, vozilo v, zupanija z WHERE r.vozilo_id = v.vozilo_id AND r.adresa_polaska_id = a.adresa_id AND a.zupanija_id = z.zupanija_id AND z.moderator_id = '$user_id' AND r.status = 1 AND r.komentar IS NULL";
	$result1 = executeQ($conn, $Q1);
	if(mysqli_num_rows($result1) != 0){
		echo "<form method='POST' action='moderator-feedback.php'>
			<table style='padding:2%; padding-bottom: 0%;'>
			<caption><h2>Dodaj komentar</h2></caption>
			<tbody>
			<tr>
			<th>Od</th>
			<th>Do</th>
			<th>Vrijeme polaska</th>
			<th>Vrijeme dolaska</th>
			</tr>";

		while ($row1 = mysqli_fetch_array($result1)) {
		$reservation_id = $row1['rezervacija_id'];
		$from = $row1['ulica'];
		$to = $row1['adresa_odredista_id'];
		echo "<tr><td>";
		echo $from;
		echo "</td><td>";
		$Q2 = "SELECT ulica FROM adresa WHERE adresa_id = '$to'";
		$result2 = executeQ($conn, $Q2);

		while ($row2 = mysqli_fetch_array($result2)) {
			echo $row2['ulica'];
		}
		echo "</td><td>";
		$date_time_start = $row1['datum_vrijeme_polaska'];
		$time_start = date('d.m.Y. H:i:s', strtotime($date_time_start));
		echo ($time_start);
		echo "</td><td>";
		$date_time_end = $row1['datum_vrijeme_dolaska'];
		$time_end = date('d.m.Y. H:i:s', strtotime($date_time_end));
		echo ($time_end);
		echo "</td>";
		echo "<input type='hidden' name='reservation_id' value='$reservation_id'>";
		echo '<td><label for="comment"><strong></strong></label>
				<input type="text" name="comment" placeholder="Dodaj komentar"/></td>

				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Komentiraj"/>
				</td>
			</tr>';
		}
	echo "</tbody>
		</table>
		</form>";}

	$Q1 = "SELECT r.komentar, r.adresa_polaska_id, r.adresa_odredista_id, r.datum_vrijeme_polaska, r.datum_vrijeme_dolaska, v.oznaka, a.ulica, r.rezervacija_id FROM adresa a, rezervacija r, vozilo v, zupanija z WHERE r.vozilo_id = v.vozilo_id AND r.adresa_polaska_id = a.adresa_id AND a.zupanija_id = z.zupanija_id AND z.moderator_id = '$user_id' AND r.status = 1 ORDER BY r.`datum_vrijeme_dolaska` DESC";
	$result1 = executeQ($conn, $Q1);
	echo "<table style='padding: 2%;'>
		<caption><h2>Prošle vožnje</h2></caption>
		<tbody>
		<tr>
		<th>Od</th>
		<th>Do</th>
		<th>Vrijeme polaska</th>
		<th>Vrijeme dolaska</th>
		<th>Komentari</th>
		</tr>";

	while ($row1 = mysqli_fetch_array($result1)) {
		$reservation_id = $row1['rezervacija_id'];
		$from = $row1['ulica'];
		$to = $row1['adresa_odredista_id'];
		echo "<tr><td>";
		echo $from;
		echo "</td><td>";
		$Q2 = "SELECT ulica FROM adresa WHERE adresa_id = '$to'";
		$result2 = executeQ($conn, $Q2);
		while ($row2 = mysqli_fetch_array($result2)) {
			echo $row2['ulica'];
		}
		echo "</td><td>";
		$date_time_start = $row1['datum_vrijeme_polaska'];
		$time_start = date('d.m.Y. H:i:s', strtotime($date_time_start));
		echo ($time_start);
		echo "</td><td>";
		$date_time_end = $row1['datum_vrijeme_dolaska'];
		$time_end = date('d.m.Y. H:i:s', strtotime($date_time_end));
		echo ($time_end);
		echo "</td><td>";
		echo $row1['komentar'];
		echo "</td>";
	}
echo "</tbody>
	</table>";
}
		


 ?>