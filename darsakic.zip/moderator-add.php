<?php 
include "header.php";
$conn=dbConn();

if (isset($_POST['submit'])) {
	$place_id = $_POST['place_id'];
	$city = $_POST['city'];
	$street = $_POST['street'];
	if (!empty($place_id) && !empty($city) && !empty($street)) {
		$Q = "INSERT INTO adresa(zupanija_id, grad, ulica) VALUES ($place_id, '$city', '$street')";
	executeQ($conn, $Q);
	header('Location: moderator.php');
	}else{
		echo "<div class='alert alert-danger'>Molimo popunite sva polja!</div>";
	}
	
}
if(isset($_SESSION['username']) && $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
	
	echo '<form method="POST" action="moderator-add.php">
		<table style="padding: 4%;">
		<caption><h2>Dodaj novu adresu</h2></caption>
		<tbody>
		<tr>
				<td>
					<label for="place_id"><strong>Županija</strong></label>
				</td>
				<td>
					<select id="place_id" name="place_id">';
					if ($_SESSION['user_type'] == 0) {
						$Q = "SELECT zupanija_id, naziv FROM zupanija";
						$result = executeQ($conn, $Q);
						while ($row = mysqli_fetch_array($result)) {
							$name = $row['naziv'];
							$place_id = $row['zupanija_id'];
								echo "<option value='$place_id'>$name</option>";
							}
					}else{
						$Q = "SELECT zupanija_id, naziv FROM zupanija WHERE moderator_id = '$user_id'";
						$result = executeQ($conn, $Q);
						while ($row = mysqli_fetch_array($result)) {
							$name = $row['naziv'];
							$place_id = $row['zupanija_id'];
							echo "<option value='$place_id'>$name</option>";
						}
					}
		echo '</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="city"><strong>Grad</strong></label>
					<input type="text" name="city"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="street"><strong>Ulica</strong></label>
					<input type="text" name="street"/>
				</td>
				</tr>';
		echo '<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Dodaj"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';



}else{
	header('Location:index.php');}
	
 ?>
