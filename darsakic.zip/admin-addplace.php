<?php 
include "header.php";
$conn=dbConn();

if (isset($_POST['submit'])) {
	$user_id = $_POST['type'];
	$place = $_POST['place'];
	$cars = $_POST['cars'];
	$sign = $_POST['sign'];

	if (!empty($user_id) && !empty($place) && !empty($cars) && !empty($sign)) {
		$Q = "INSERT INTO zupanija(moderator_id, naziv, broj_vozila) VALUES ('$user_id', '$place', '$cars')";
	executeQ($conn, $Q);

	for ($i=1; $i <= $cars; $i++) { 
		$taxi = "TAXI-".$sign."-".$i;
		$Q = "SELECT zupanija_id FROM zupanija WHERE naziv = '$place'";
		$result = executeQ($conn, $Q);
		$row = mysqli_fetch_array($result);
		$place_id = $row['zupanija_id'];
		$Qone = "INSERT INTO vozilo (zupanija_id, oznaka) VALUES ('$place_id', '$taxi')";
			executeQ($conn, $Qone);
	header("Location: admin-place.php");
	}
	
	}else{
		echo "<div class='alert alert-danger'>Molimo popunite sva polja!</div>";
	}
	
}
if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	
	echo '<form method="POST" action="admin-addplace.php">
	<table style="padding:2%;">
		<caption><h2>Dodaj novu županiju</h2></caption>
		<tbody>
		<tr>
				<td>
					<label for="type"><strong>Moderator</strong></label>
				</td>
				<td>
					<select id="type" name="type">';
					$Q = "SELECT korisnik_id, ime, prezime FROM korisnik WHERE tip_id = 1";
					$result = executeQ($conn, $Q);
					while ($row = mysqli_fetch_array($result)) {
						$name = $row['ime'];
						$lastname = $row['prezime'];
						$user_id = $row['korisnik_id'];
									echo "<option value='$user_id'>$name $lastname</option>";}
		echo '</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="place"><strong>Županija</strong></label>
					<input type="text" name="place"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="sign"><strong>Oznaka županije</strong></label>
					<input type="text" name="sign"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="cars"><strong>Broj vozila</strong></label>
					<input type="number" name="cars"/>
				</td>
				</tr>';
		echo '<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Dodaj"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';


}
	
 ?>
