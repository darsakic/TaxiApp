<nav>
<?php 
switch ($user_type) {
	case '0':
			echo '<a class="navi" href="index.php"> POČETNA </a> ';
			echo '<a class="navi" href="admin.php"> KORISNICI </a> ';
			echo '<a class="navi" href="admin-adduser.php"> DODAJ KORISNIKA </a> ';
			echo '<a class="navi" href="admin-place.php"> ŽUPANIJE </a> ';
			echo '<a class="navi" href="admin-addplace.php"> DODAJ ŽUPANIJU </a> ';
			echo '<a class="navi" href="admin-request.php"> ZAHTJEVI </a> ';
			echo '<a class="navi" href="moderator.php"> UREDI ADRESE </a> ';
			echo '<a class="navi" href="moderator-add.php"> DODAJ ADRESU </a> ';
			echo '<a class="navi" href="admin-toplist.php"> TOP LISTA VOZILA </a> ';
			echo '<a class="navi" href="admin-topadress.php"> TOP LISTA ADRESA </a> ';
			echo '<a class="navi" href="admin-feedback.php"> FEEDBACK </a> ';
		break;
	
	case '1':
			echo '<a class="navi" href="index.php"> POČETNA </a> ';
			echo '<a class="navi" href="moderator-request.php"> ZAHTJEVI </a> ';
			echo '<a class="navi" href="moderator.php"> ŽUPANIJE </a> ';
			echo '<a class="navi" href="moderator-add.php"> DODAJ ADRESU </a> ';
			echo '<a class="navi" href="moderator-toplist.php"> TOP LISTA VOZILA </a> ';
			echo '<a class="navi" href="moderator-topadress.php"> TOP LISTA ADRESA </a> ';
			echo '<a class="navi" href="moderator-feedback.php"> FEEDBACK </a> ';
		break;
	case '2';
			echo '<a class="navi" href="index.php"> POČETNA </a> ';
			echo '<a class="navi" href="user-feedback.php"> FEEDBACK </a> ';
		break;
	default:
		echo '<a class="nav" href="index.php"> POČETNA </a> ';
		break;
}
 ?>
 </nav>