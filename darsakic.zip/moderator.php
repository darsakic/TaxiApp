<?php 
include "header.php";
$conn=dbConn();



if(isset($_SESSION['username']) && $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];

	if ($_SESSION['user_type'] == 0) {
    $Q = "SELECT zupanija_id, naziv FROM zupanija";
    $result = executeQ($conn, $Q);
    echo "<div>";
    while ($row = mysqli_fetch_array($result)) {
      $zupanija_id = $row['zupanija_id'];
      echo '<div>';
      echo "<table>";
      echo "<th>{$row['naziv']}</th>";

      $Q = "SELECT adresa_id, grad, ulica FROM adresa WHERE zupanija_id = '$zupanija_id'";
      $result1 = executeQ($conn, $Q);

      while ($row1 = mysqli_fetch_array($result1)) {
        $id = $row1['adresa_id'];
        echo "<tr><td>{$row1['ulica']}</td>";
        echo "<td><a class='link' href='moderator-edit.php?adresa=$id'>UREDI</a></td></tr>";
      }
            
      echo "</table>";
      echo '</div>';
    }
    echo "</div>";
  } else{
    $Q = "SELECT zupanija_id, naziv FROM zupanija WHERE moderator_id = $user_id";
    $result = executeQ($conn, $Q);
    echo "<div>";

    while ($row = mysqli_fetch_array($result)) {
      $zupanija_id = $row['zupanija_id'];
			echo "<table>";
      echo "<th>{$row['naziv']}</th>";

      $Q = "SELECT adresa_id, grad, ulica FROM adresa WHERE zupanija_id = '$zupanija_id'";
      $result1 = executeQ($conn, $Q);

      while ($row1 = mysqli_fetch_array($result1)) {
        $id = $row1['adresa_id'];
        echo "<tr><td>{$row1['ulica']}</td>";
        echo "<td><a class='link' href='moderator-edit.php?adresa=$id'>UREDI</a></td></tr>";
      }
            
    echo "</table>";
    }
  echo "</div>";
  }
}else{
  header("Location:index.php");
}
    ?>