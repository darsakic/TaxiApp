<?php 
include "header.php";
$conn = dbConn();
if (isset($_POST['submit'])) {

	$place = $_POST['place'];
	$cars = $_POST['numcars'];
	$type = $_POST['type'];
	$sign = $_POST['oznaka'];
	$place_id = $_POST['place_id'];
	$oldnumcars = $_POST['oldnumcars'];
	$numcars = $cars + $oldnumcars;
	$Q = "UPDATE zupanija SET moderator_id = '$type', naziv = '$place',  broj_vozila = '$numcars' WHERE zupanija_id = '$place_id'";
	executeQ($conn, $Q);

	if ($cars > 0) {
		for ($i = $oldnumcars + 1; $i <= $numcars; $i++) { 
		$taxi = "TAXI-".$sign."-".$i;
		$Qone = "INSERT INTO vozilo (zupanija_id, oznaka) VALUES ('$place_id', '$taxi')";
		executeQ($conn, $Qone);
		}
	}
	header("Location: admin-place.php");	

}

if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	if (isset($_GET['zupanija'])) {
		$place_id = $_GET['zupanija'];

	echo '<form method="POST" action="admin-updateplace.php">
		<table style="padding:2%;">
		<caption><h2>Uredi županiju</h2></caption>
		<tbody>
		<tr>
				<td>
					<label for="type"><strong>Moderator </strong></label>
				
					<select id="type" name="type">';
					$Q1 = "SELECT moderator_id FROM zupanija WHERE zupanija_id = $place_id";
					$result1 = executeQ($conn, $Q1);
					$row1 = mysqli_fetch_array($result1);
					$moderator_id = $row1['moderator_id'];
									
					$Q = "SELECT korisnik_id, ime, prezime FROM korisnik WHERE tip_id = 1";
					$result = executeQ($conn, $Q);

					while ($row = mysqli_fetch_array($result)) {
						$name = $row['ime'];
						$lastname = $row['prezime'];
						$user_id = $row['korisnik_id'];
						echo "<option value='$user_id' ";
									
						if($moderator_id == $user_id){
							echo "selected='selected'";
						}
					echo ">$name $lastname</option>";}
		echo '</select>
				</td>
			</tr>
		</td>
			</tr>
			<tr>
				<td>
					<label for="place"><strong>Županija </strong></label>';

					$Q = "SELECT * FROM zupanija WHERE zupanija_id = '$place_id'";
					$result = executeQ($conn, $Q);

					while ($row = mysqli_fetch_array($result)) {
						$place = $row['naziv'];
						$place_id = $row['zupanija_id'];
						echo "<input type='hidden' name='place_id' value='$place_id'>";
									echo "<input name='place' value='$place'>";};
		echo '</td>
			</tr>';

					$Q1 = "SELECT * FROM vozilo WHERE zupanija_id = '$place_id'";
					$result1 = executeQ($conn, $Q1);
					$row1 = mysqli_fetch_array($result1);
					$sign = $row1['oznaka'];
					$signone = substr($sign, 5, -2);
					echo "<input name='oznaka' type='hidden' value='$signone'>";
		echo '<tr>
			<td>
				<label for="numcars"><strong>Dodajte nova vozila </strong></label>';

					$Q = "SELECT broj_vozila FROM zupanija WHERE zupanija_id = '$place_id'";
					$result = executeQ($conn, $Q);
					while ($row = mysqli_fetch_array($result)) {
						$cars = $row['broj_vozila'];
						echo "<input name='oldnumcars' type='hidden' value='$cars'>";
						echo "<input type='number' name='numcars' placeholder='Trenutni broj vozila je $cars'>";};
		echo '</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Ažuriraj"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';


}
}
	
 ?>