</section>
<footer style="position: absolute; bottom: 0; left: 50%; text-align: center;
overflow: hidden;">
	<p>
	
	<address> Kontakt osoba: <a href="mailto:darsakic@foi.hr">Dario Šakić</a></address>
	<a> Izrada: Veljača, 2020.</a></br>
	<a> &copy; Dario Šakić</a>
	
</p>
</footer>
</body>
</html>