<?php 
include 'header.php';
$conn = dbConn();

if (isset($_POST['submit'])){
	$username = mysqli_real_escape_string($conn, $_POST['username']);
	$password = mysqli_real_escape_string($conn, $_POST['password']);

	if(empty($username) || empty($password)){
		echo "<div class='alert alert-danger'>Molimo unesite valjano korsničko ime i lozinku!</div>";
	}
	else {
		$Q = "SELECT korisnik_id, tip_id, korisnicko_ime, lozinka, ime, prezime FROM korisnik WHERE korisnicko_ime='{$username}' AND lozinka='{$password}'";
		$result=executeQ($conn, $Q);
		if(mysqli_num_rows($result) == 0){
			echo "<div class='alert alert-danger'>Pogrešno korisničko ime ili lozinka. Molimo pokušajte ponovnu prijavu sa važećim podacima!</div>";
		}else{
			$row = mysqli_fetch_assoc($result);
			$_SESSION['username'] = $row['korisnicko_ime'];
			$_SESSION['name'] = $row['ime'];
			$_SESSION['lastname'] = $row['prezime'];
			$_SESSION['user_type'] = $row['tip_id'];
			$_SESSION['user_id'] = $row['korisnik_id'];
			if($_SESSION['user_type'] == 1){
				header("Location:moderator-request.php");
			}else{
				header("Location:index.php");
			}

		}
	}
	

}
 ?>
 
<div  style="text-align: center;">
 <form method="POST" action="login.php">
	<table  class="login"  style="float:none; margin: 0%;">
		<caption> <h2>Prijava u sustav</h2></caption>
		<tbody>
			
			<tr>
				<td>
					<label for="username"><strong>Korisničko ime:</strong></label>
				</td>
				<td>
					<input name="username" id="username" type="text"/>
				</td>
			</tr>
			<tr>
				<td>
					<label for="password"><strong>Lozinka:</strong></label>
				</td>
				<td>
					<input name="password"	id="password" type="password"/>
				</td>
			</tr>
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Prijavi se"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>
</div>