<?php
include "header.php";
$conn = dbConn();

$reservation_id = $_GET['rezervacija'];
$Q = "UPDATE rezervacija SET status = '2' WHERE rezervacija_id = '$reservation_id'";
executeQ($conn, $Q);
$_SESSION['deny'] = "Rezervacija " . $reservation_id . " uspješno odbijena!";

if ($_SESSION['user_type'] == 1) {
	header('Location: moderator-request.php');
}elseif ($_SESSION['user_type'] == 0) {
	header('Location: admin-request.php');
}
?>