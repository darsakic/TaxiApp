<?php 

include "header.php";
$conn = dbConn();

$Q = "SELECT * FROM zupanija";
$result = executeQ($conn, $Q);
echo "<table style='padding: 2%;'>";
echo "<tr><th>Županije</tr></th>";

while ($row = mysqli_fetch_array($result)) {
	echo "<tr>";
	echo "<td><a href='admin-toplist.php?zupanija={$row['zupanija_id']}'>{$row['naziv']}</a></td>";
    echo "</tr>";
}
echo "</table>";

if (isset($_POST['submit'])) {
	$place_id = $_POST['place'];
	$date_start = $_POST['date_start'];
    $date_start = date('Y-m-d', strtotime($date_start));
    $time_start = $_POST['time_start'];

    $date_end = $_POST['date_end'];
    $date_end = date('Y-m-d', strtotime($date_end));
    $time_end = $_POST['time_end'];

    $date_time_start = $date_start . ' ' . $time_start;
    $date_time_end = $date_end . ' ' . $time_end;
    
    $date_time_start = date('Y-m-d H:i:s', strtotime($date_time_start));
    $date_time_end = date('Y-m-d H:i:s', strtotime($date_time_end));
    

    $Q = "SELECT z.naziv AS zupanija, v.oznaka AS oznaka, COUNT(*) AS odradeni_prijevozi 
	FROM rezervacija r, vozilo v, zupanija z 
	WHERE r.vozilo_id = v.vozilo_id AND v.zupanija_id = z.zupanija_id AND v.zupanija_id = '$place_id' AND r.datum_vrijeme_dolaska
	BETWEEN '$date_time_start'AND '$date_time_end' AND r.status = 1 
	GROUP BY v.oznaka ORDER BY odradeni_prijevozi DESC";
	$result = executeQ($conn, $Q);
	echo "<table style='padding: 2%;'>";
	echo "<tr><th>Vozilo</th>";
	echo "<th>Odrađeni prijevozi</th></tr>";

	while($row = mysqli_fetch_array($result)){
		echo "<tr><td>{$row['oznaka']}</td>";
		echo "<td>{$row['odradeni_prijevozi']}</td></tr>";
	}
	echo "</table>";
}


if (isset($_SESSION['username']) && $_SESSION['user_type'] == 0) {
	if(isset($_GET['zupanija'])){
		$place_id = $_GET['zupanija'];
        echo "<form method='POST' action='admin-toplist.php'>
        	<input type='hidden' name='place' value='$place_id'>
			<table style='padding: 2%;'>
			<caption><h2>Ukupan broj odrađenih prijevoza po vozilu</h2></caption>
			<tbody>";
		echo '
            <tr>
				<td><label for="date_start"><strong>Od:</strong></label></td>
				<td><input type="text" onClick="setDate(this)" name="date_start" id="datum" placeholder="npr. 01.01.2020"/></td>

				<td><label for="time_start"><strong></strong></label></td>
				<td><input type="text" onClick="setTime(this)" name="time_start" id="vrijeme" placeholder="npr. 13:00:00"/></td>
			</tr>
			<tr>
				<td><label for="date_end"><strong>Do:</strong></label></td>
				<td><input type="text" onClick="setDate(this)" name="date_end" id="datum" placeholder="npr. 01.01.2020"/></td>

				<td><label for="time_end"><strong></strong></label></td>
				<td><input type="text" onClick="setTime(this)" name="time_end" id="vrijeme" placeholder="npr. 13:00:00"/></td>
			</tr>
            
            
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Pretraži"/>
				</td>
			</tr>
		</tbody>
		</table>
		</form>';
	}
}else{
	header("Location:index.php");
}
 ?>