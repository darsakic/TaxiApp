<?php 
include "header.php";
$conn=dbConn();

if (isset($_POST['submit'])) {
	$name = $_POST['name'];
	$lastaname = $_POST['lastname'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	$type = $_POST['type'];
	$image = $_POST['image'];

	if (!empty($name) && !empty($username) && !empty($password)) {
		$Q = "SELECT email FROM korisnik WHERE email = '$email'";
		$result = executeQ($conn, $Q);
		$row = mysqli_fetch_array($result);
		$Qone = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = '$username'";
		$resultone = executeQ($conn, $Qone);
		$rowone = mysqli_fetch_array($resultone);
			if (!empty($row)) {
				var_dump($row);
				echo "<div class='alert alert-danger'>Korisnik s takvim emailom već postoji!</div>";
			}else if(!empty($rowone)){
				var_dump($rowone);
				echo "<div class='alert alert-danger'>Korisnik s takvim korisničkim imenom već postoji!</div>";
			}else{
				$Q = "INSERT INTO korisnik(tip_id, korisnicko_ime, lozinka, ime, prezime, email, slika) VALUES ('$type', '$username', '$password', '$name', '$lastaname', '$email', '$image')";
				executeQ($conn, $Q);
				header('Location:admin.php');
			}
		
	}else{
		echo "<div class='alert alert-danger'>Molimo popunite sva obavezna polja!</div>";
	}
	
}

if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
	
	echo '<form method="POST" action="admin-adduser.php">
	<table style="padding: 2%;">
		<caption><h2>Dodaj novog člana</h2></caption>
		<tbody>
		<tr>
				<td>
					<label for="type"><strong>Tip korisnika</strong></label>
				</td>
				<td>
					<select id="type" name="type">';
					$Q = "SELECT tip_id, naziv FROM tip_korisnika";
					$result = executeQ($conn, $Q);
					while ($row = mysqli_fetch_array($result)) {
						$naziv = $row['naziv'];
						$type_id = $row['tip_id'];
									echo "<option value='$type_id' select='selected'>$naziv</option>";}
		echo '</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="name"><strong>Ime</strong></label>
					<input type="text" name="name"/>
				</td>
				</tr>';
		echo '</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="lastname"><strong>Prezime</strong></label>
					<input type="text" name="lastname"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="username"><strong>Korisničko ime</strong></label>
					<input type="text" name="username"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="email"><strong>Email</strong></label>
					<input type="text" name="email"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="password"><strong>Lozinka</strong></label>
					<input type="password" name="password"/>
				</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="type"><strong>Slika</strong></label>
				</td>
				<td>
					<select id="image" name="image">';
					$images = scandir('korisnici');
					foreach ($images as $key => $value) {
							echo '<option value="'."korisnici/".$value.'">';
							echo "korisnici/".$value;
							echo '</option>';
					};
		echo '</select>
				</td>
			</tr>';
		echo '<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Dodaj"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';


}else{
	header('Location:index.php');
}
	
 ?>
