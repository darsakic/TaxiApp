<?php
	

	function dbConn(){
		$username = "iwa_2017";
	$password = "foi2017";
	$hostname = "localhost";
	$db_name = "iwa_2017_kz_projekt";
		$connection=mysqli_connect($hostname, $username, $password, $db_name);
		if(!$connection)echo "GREŠKA: Problem sa spajanjem! Datoteka database.php funkcija dbConn: ".mysqli_connect_error();

		mysqli_select_db($connection,$db_name);
		if(mysqli_error($connection)!=="")echo "GREŠKA: Problem sa spajanjem! Datoteka database.php funkcija dbConn: ".mysqli_error($connection);

		mysqli_set_charset($connection,"utf8");
		if(mysqli_error($connection)!=="")echo "GREŠKA: Problem sa spajanjem! Datoteka database.php funkcija dbConn: ".mysqli_error($connection);
		return $connection;
	}

	function executeQ($connection,$query){
		$result=mysqli_query($connection,$query);
		if(mysqli_error($connection)!=="")echo "GREŠKA: Problem sa upitom: ".$query."! Datoteka database.php funkcija executeQ: ".mysqli_error($connection);
		return $result;
	}

	function closeConn($connection){
		mysqli_close($connection);
	}
?>
