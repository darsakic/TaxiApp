<?php 

include "header.php";
$conn = dbConn();

$moderator_id = $_SESSION['user_id'];
$Q = "SELECT * FROM zupanija";
$result = executeQ($conn, $Q);
echo "<table style='padding: 2%;'>";
echo "<tr><th>Županije</tr></th>";

while ($row = mysqli_fetch_array($result)) {
	echo "<tr>";
	echo "<td><a href='admin-topadress.php?zupanija={$row['zupanija_id']}'>{$row['naziv']}</a></td>";
    echo "</tr>";  
}
echo "</table>";

if (isset($_SESSION['username']) && $_SESSION['user_type'] == 0) {
	if (isset($_GET['zupanija'])) {
		$place_id = $_GET['zupanija'];
	
		$Q = "SELECT a.ulica, a.grad, COUNT(*) AS broj_rezervacija 
		FROM rezervacija r, adresa a, zupanija z 
		WHERE r.adresa_polaska_id = a.adresa_id AND a.zupanija_id = z.zupanija_id AND z.zupanija_id = '$place_id' AND r.status = 1
		GROUP BY a.ulica ORDER BY broj_rezervacija DESC";

		$result = executeQ($conn, $Q);
		echo "<table style='padding: 2%;'>";
		echo "<caption><h2>Adrese sa najviše rezervacija</h2></caption>";
		echo "<tr><th>Grad</th>";
		echo "<th>Adresa</th>";
		echo "<th>Broj rezervacija</th></tr>";
			while ($row = mysqli_fetch_array($result)){
				echo "<tr><td>{$row['grad']} </td>";
				echo "<td>{$row['ulica']}</td>";
				echo "<td>{$row['broj_rezervacija']}</td></tr>";
			}
		echo "</table>";
	}
}

 ?>