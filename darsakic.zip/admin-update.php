<?php 
include "header.php";
$conn = dbConn();

if (isset($_POST['submit'])) {
	$user_type = $_POST['type'];
	$name = $_POST['name'];
	$lastname = $_POST['lastname'];
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$image = $_POST['image'];
	$user_id = $_POST['user_id'];

	$Q = "UPDATE korisnik SET  tip_id = '$user_type', korisnicko_ime = '$username', lozinka = '$password', ime = '$name', prezime = '$lastname', email = '$email', slika = '$image' WHERE korisnik_id = '$user_id'";
	executeQ($conn, $Q);
	header("Location: admin.php");
}

if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	if (isset($_GET['user'])) {
		$id = $_GET['user'];
	echo '<form method="POST" action="admin-update.php">
		<table style="padding:2%;">
		<caption><h2>Ažuriraj člana</h2></caption>
		<tbody>
		<tr>
			<td>
				<label for="type"><strong>Tip korisnika</strong></label>
			</td>
			<td>
				<select id="type" name="type">';
				$Q = "SELECT tip_id, ime, korisnik_id FROM korisnik WHERE korisnik_id = '$id'";
				$result = executeQ($conn, $Q);
				$row = mysqli_fetch_array($result);
				$type_id = $row['tip_id'];
				echo "<option value='0' ";if ($type_id == 0) {
					echo "selected='selected'";
				};
				echo ">Administrator</option>";
				echo "<option value='1' ";if ($type_id == 1) {
					echo "selected='selected'";
				};
				echo ">Moderator</option>";
				echo "<option value='2' ";if ($type_id == 2) {
						echo "selected='selected'";
				};
				echo ">Korisnik</option>";	
				echo '</select>
			</td>
		</tr>
		<tr>
			<td>
				<label for="name"><strong>Ime </strong></label>';
				$Q = "SELECT * FROM korisnik WHERE korisnik_id = '$id'";
				$result = executeQ($conn, $Q);
				$row = mysqli_fetch_array($result);
				$name = $row['ime'];
				$lastname = $row['prezime'];
				$username = $row['korisnicko_ime'];
				$password = $row['lozinka'];
				$email = $row['email'];
				$user_id = $row['korisnik_id'];
					echo "<input type='hidden' name='user_id' value='$user_id'>";
					echo "<input name='name' value='$name'>";
		echo "</td>
		</tr>
		<tr>
			<td>
				<label for='lastname'><strong>Prezime </strong></label>
					<input type='text' name='lastname' value='$lastname'/>
			</td>
		</tr>";
		echo "<tr>
				<td>
					<label for='username'><strong>Korisničko ime </strong></label>
					<input type='text' name='username' value='$username'/>
				</td>
				</tr>";
		echo "<tr>
				<td>
					<label for='email'><strong>Email </strong></label>
					<input type='text' name='email' value='$email'/>
				</td>
				</tr>";
		echo "<tr>
				<td>
					<label for='password'><strong>Lozinka </strong></label>
					<input type='text' name='password' value='$password'/>
				</td>
				</tr>";
			echo '<tr>
				<td>
					<label for="image"><strong>Slika</strong></label>
				<td>
					<select id="image" name="image">';
					$Q = "SELECT slika FROM korisnik WHERE korisnik_id = '$id'";
					$result = executeQ($conn, $Q);
					$row = mysqli_fetch_array($result);
					$picture = substr($row['slika'], 10);
					$images = scandir('korisnici');

					foreach ($images as $key) {
						echo '<option name="image" value="'."korisnici/".$key.'"';
						if ($picture == $key) {
							echo ' selected="selected"';
						}
						echo '>'."korisnici/".$key;
						echo '</option>';
					};
					
		echo '</select>
				</td>
			</tr>';
		echo '<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Uredi"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';
}
}
	
 ?>