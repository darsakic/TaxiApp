<?php
	include("database.php");
	session_start();
	
	$username=0;
	$user_type=-1;

	if(isset($_SESSION['username'])){
		$username=$_SESSION['username'];
		$name=$_SESSION['name'];
		$lastname=$_SESSION['lastname'];
		$user_type=$_SESSION['user_type'];
		$user_id=$_SESSION["user_id"];
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>IWA projekt 2020. - Taksi prijevoz</title>
  		<meta name="autor" content="Dario Sakic" />
  		<meta name="datum" content="veljača, 2020." />
  		<meta name="kolegij" content="Izrada Web Aplikacija - IWA">
  		<meta charset="utf-8" />
  		<link href="style.css" rel="stylesheet" type="text/css" >
	</head>
	<body>
		<script type="text/javascript">
        function setDate(text) {
            var currentTime = new Date();
            var month = currentTime.getMonth() + 1;
            var day = currentTime.getDate();
            var year = currentTime.getFullYear();
            
            text.value=day + "." + month + "." + year + ".";
        }
        function setTime(text) {
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();
            var seconds = currentTime.getSeconds();
            
            text.value=hours + ":" + minutes + ":" + seconds;
        }
        </script>
		<header style="text-align: center;">
			<span>
				<strong style="font-size: 20px;">IWA projekt 2020. - Taksi prijevoz</strong>
				<br/>
				</span>
					<span class="status">
				<a href="o_autoru.html">Autor</a></span></br>
				<?php
					if($username === 0){
						echo "<span class='status'  style='padding-top: 1%'><strong>Status: </strong>Neprijavljeni korisnik</span><br/>";
						echo "<a class='log' href='login.php'>Prijava</a>";
					}
					else{
						echo "<span class='status' style='padding-top: 1%'><strong>Status: </strong>Dobrodošli, $name $lastname</span><br/>";
						echo "<a class='log' href='logout.php'>Odjava</a>";
					}
				?>
			</span>
		</br>
			<?php include "nav.php"; ?>
		</header>
		</nav>
		<section>
