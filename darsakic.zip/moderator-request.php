<?php 
include "header.php";
$conn=dbConn();


if(isset($_SESSION['username']) && $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
  $Q = "SELECT * FROM rezervacija r, adresa a, zupanija z 
  WHERE r.adresa_polaska_id = a.adresa_id AND a.zupanija_id = z.zupanija_id 
  AND z.moderator_id = '$user_id' AND r.status = 0 ORDER BY rezervacija_id DESC";
  $result = executeQ($conn, $Q);

  if(isset($_SESSION['confirm'])){
    echo '<div style= "text-align:center; padding: 2%;"><h4 style="color: white;"> ' . $_SESSION['confirm'] . ' </h4></div>';
    unset($_SESSION['confirm']);
  }

  if(isset($_SESSION['error'])){
    echo '<div style= "text-align:center; padding: 2%;"><h4 style="color: white;"> ' . $_SESSION['error'] . ' </h4></div>';
    unset($_SESSION['error']);
  }

  if(isset($_SESSION['deny'])){
    echo '<div style= "text-align:center; padding: 2%;"><h4 style="color: white;"> ' . $_SESSION['deny'] . ' </h4></div>';
    unset($_SESSION['deny']);
  }

  if($row = mysqli_num_rows($result) == 0){
    echo '<div style= "text-align:center; padding-top: 2%;"><h2> Nemate zahtjeva za rezervacije </h2></div>';
  }else {
    echo '<div>
        <table>
        <caption><h2> Zahtjevi za rezervaciju <h2></caption>
        <tr><th>Broj rezervacije</th>
            <th>Adresa polaska</th>
            <th>Adresa odredišta</th>
            <th>Vrijeme polaska</th>
            <th>Vozilo</th></tr>';
  
        while ($row = mysqli_fetch_array($result)) {
            $Q2 = "SELECT ulica FROM adresa WHERE adresa_id = " . $row['adresa_odredista_id'];
            $result2 = executeQ($conn, $Q2);
            $row2 = mysqli_fetch_array($result2);
           
            $Q3 = "SELECT oznaka FROM vozilo WHERE vozilo_id = " . $row['vozilo_id'];
            $result3 = executeQ($conn, $Q3);
            $row3 = mysqli_fetch_array($result3);

            $date_time_start = $row['datum_vrijeme_polaska'];
            $date_start = date('d.m.Y H:i:s', strtotime($date_time_start));
            echo '<tr>
                <td>'. $row['rezervacija_id'] . '</td>
                <td>'. $row['ulica'] .'</td>
                <td>'. $row2['ulica'] . '</td>
                <td>'. $date_start . '</td>
                <td>'. $row3['oznaka'] . '</td>';
            echo "<td><a href='moderator-confirm.php?rezervacija={$row['rezervacija_id']}&vozilo={$row['vozilo_id']}'>POTVRDI</a></td>";
            echo "<td><a href='moderator-deny.php?rezervacija={$row['rezervacija_id']}'>ODBIJ</a></td></tr>";
        }
    }
    
    
    echo    '</table>
    </div>';


}
    ?>