<?php 
include "header.php";
$conn=dbConn();


if(isset($_SESSION['username']) && $_SESSION['user_type'] == 1 || $_SESSION['user_type'] == 0){

	if (isset($_POST['edit'])) {
		$adress = $_POST['adress'];
		$city = $_POST['city'];
		$street = $_POST['street'];
		$Q = "UPDATE adresa SET grad = '$city', ulica = '$street' WHERE adresa_id = '$adress'";
		$result = executeQ($conn, $Q);
		header('Location: moderator.php');
	}

	if (isset($_GET['adresa'])) {
		$Q = "SELECT adresa_id, grad, ulica FROM adresa WHERE adresa_id = ".$_GET["adresa"]."";
		$result = executeQ($conn, $Q);
		$row = mysqli_fetch_array($result);
		$city = $row['grad'];
		$street = $row['ulica'];
		$adress_id = $row['adresa_id'];
	
		echo '<form method="POST" action="moderator-edit.php">
			<table style="padding: 2%; padding-left: 10%;">';
		echo "<caption><h3>Uredi adresu <p style='color: white;'>{$row['ulica']}</p> iz grada {$row['grad']}</h3></caption>";
					echo '<input type="hidden" name="adress" value="';
		echo ($adress_id);
		echo '">';
		echo '<tbody>
			<tr>
				<td>
					<label for="city"><strong>Grad </strong></label>';
		echo '<input type="text" name="city" value="';
		echo ($city);
		echo '">';

		echo '</td>
				</tr>';
		echo '<tr>
				<td>
					<label for="street"><strong>Ulica </strong></label>';
					echo '<input type="text" name="street" value="';
		echo ($street);
		echo '">';

		echo '</td>
				</tr>';
		echo '<tr>
				<td colspan="2" style="text-align:center;">
					<input name="edit" type="submit" value="Uredi"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>';
}


}
 ?>