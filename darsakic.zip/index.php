<?php
include "header.php";
$conn = dbConn();

if(isset($_SESSION['confirm1'])){
               echo '<div style= "text-align:center; padding: 2%;"><h4 style="color: white;"> ' . $_SESSION['confirm1'] . ' </h4></div>';
               unset($_SESSION['confirm1']);
           }
if(isset($_SESSION['error1'])){
               echo '<div style= "text-align:center; padding: 2%;"><h4 style="color: white;"> ' . $_SESSION['error1'] . ' </h4></div>';
               unset($_SESSION['error1']);
           }

if (isset($_POST['submit'])) {
    $zupanija = $_POST['zupanija'];
	$user_id=$_SESSION["user_id"];
	$start = $_POST['polazak'];
	$end = $_POST['odrediste'];
    $date_start = $_POST['datum_polaska'];
    $date_start = date('Y-m-d', strtotime($date_start));

    $time_start = $_POST['vrijeme_polaska'];
    $date_time_start = $date_start . ' ' . $time_start;
    
    $date_time_start = date('Y-m-d H:i:s', strtotime($date_time_start));
    
    $date_time_end = date_create($date_time_start);
    date_add($date_time_end, date_interval_create_from_date_string('1 hour'));
    $date_time_end = $date_time_end->format('Y-m-d H:i:s');
    
    $Q = "SELECT * FROM vozilo v 
    WHERE v.zupanija_id = '$zupanija' AND v.vozilo_id NOT IN (SELECT v.vozilo_id  FROM rezervacija r, vozilo v 
    WHERE (r.datum_vrijeme_polaska BETWEEN '$date_time_start'
    AND '$date_time_end'
    OR r.datum_vrijeme_dolaska BETWEEN '$date_time_start' AND '$date_time_end')
    AND r.vozilo_id = v.vozilo_id AND v.zupanija_id = '$zupanija' AND r.status = 1)";
    
    $result = executeQ($conn,$Q);
    $row = mysqli_fetch_array($result);

    if(mysqli_num_rows($result) > 0) {
        $vozilo = $row[0];
        $Q = "INSERT INTO rezervacija(korisnik_id, vozilo_id, adresa_polaska_id, adresa_odredista_id, datum_vrijeme_polaska, status) VALUES ('$user_id', '$vozilo', '$start', '$end', '$date_time_start', 0)";
		executeQ($conn,$Q);
		$_SESSION['confirm1'] = "Rezervacija uspješna!";
		header('Location: index.php');
    } elseif (mysqli_num_rows($result) == 0) {
    	$_SESSION['error1'] = "Sva vozila su trenutno zauzeta. Molimo pokušajte ponovno kasnije!";
    	header('Location: index.php');
    }
}


$Q = "SELECT * FROM zupanija";
$result = executeQ($conn, $Q);
echo "<div>";
echo "<table>";
echo "<caption><h2>Popis županija</h2></caption>";
while($row = mysqli_fetch_array($result)){
	echo "<tr>";
	echo "<td><a href='index.php?zupanija={$row['zupanija_id']}'>{$row['naziv']}</a></td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

if (isset($_GET['zupanija'])) {
	$Q = "SELECT a.ulica , a.grad , r.datum_vrijeme_polaska 
	FROM adresa a, rezervacija r
	WHERE a.adresa_id = r.adresa_polaska_id
	AND a.zupanija_id = ".$_GET["zupanija"]."
	ORDER BY r.datum_vrijeme_polaska DESC
	LIMIT 3";
	$result = executeQ($conn, $Q);

	if($num = mysqli_num_rows($result) == 0){
		echo '<div style=" padding: 4%; padding-top:10%; display:inline-block; float:left;"><h3> Nema podataka </h3> </div>';
	}else{
		echo '<div>';
		echo '<table style="padding: 2%; padding-top:10px;">';
		echo '<caption><h3>Posljednje 3 adrese</h3></caption>';

		while($row = mysqli_fetch_array($result)){
		 	echo "<tr>";
            echo "<td>{$row['ulica']}</td>";
            echo "</tr>";
	}

	echo "</table>";
	echo '</div>';
}
	if (isset($_SESSION['username'])) {
        echo '<div style="padding-top: 10px; padding-right:2%; display:inline-block;">
    	    <form method="POST" action="index.php">
        	<input type="hidden" name="zupanija" value=' . $_GET['zupanija'] . '>
			<table style="">
			<caption><h3>Rezerviraj vožnju</h3></caption>
			<tbody>
				<tr>
				<td class="lijevi">
					<label for="polazak"><strong>Mjesto polaska</strong></label>
				</td>
				<td>
					<select id="polazak" name="polazak">';
					$Q="SELECT * FROM adresa a, zupanija z WHERE z.zupanija_id = ".$_GET["zupanija"]." AND a.zupanija_id = z.zupanija_id";
					$result=executeQ($conn,$Q);

					while($row = mysqli_fetch_array($result)){
							echo "<option value='{$row['adresa_id']}'>{$row['ulica']}</option>";}
		echo '</select>
				</td>
			</tr>
			<tr>
				<td>
					<label for="odrediste"><strong>Odrediste</strong></label>
				</td>
				<td>
					<select id="odrediste" name="odrediste">';
					$Q="SELECT * FROM adresa a, zupanija z WHERE z.zupanija_id = ".$_GET["zupanija"]." AND a.zupanija_id = z.zupanija_id";
					$result=executeQ($conn,$Q);

					while($row = mysqli_fetch_array($result)){
						echo "<option value='{$row['adresa_id']}'>{$row['ulica']}</option>";};
		echo '</select>
				</td>
			</tr>
            
            <tr>
				<td><label for="datum_polaska"><strong>Datum polaska:</strong></label></td>
				<td><input type="text" onClick="setDate(this)" name="datum_polaska" id="datum" placeholder="npr. 01.01.2020"/></td>
			</tr>
			<tr>
				<td><label for="vrijeme_polaska"><strong>Vrijeme polaska:</strong></label></td>
				<td><input type="text" onClick="setTime(this)" name="vrijeme_polaska" id="vrijeme" placeholder="npr. 13:00:00"/></td>
			</tr>
            
            
			<tr>
				<td colspan="2" style="text-align:center;">
					<input name="submit" type="submit" value="Rezerviraj"/>
				</td>
			</tr>
		</tbody>
	</table>
</form>
</div>';

		
	}


}

if (isset($_SESSION['user_id'])) {
	$user_id = $_SESSION['user_id'];
	$Q1 = "SELECT * FROM rezervacija WHERE korisnik_id = '$user_id' ORDER BY rezervacija_id DESC";
		$result = executeQ($conn,$Q1);
		echo '<div style="padding-right:2%; float:right;">';
		echo "<table>";
		echo '<caption><h2>Popis rezervacija</h2></caption>';
		echo "<tr><th>Vrijeme vožnje</th>";
		echo "<th>Vozilo</th>";
		echo "<th>Status</th></tr>";
		
		while($row = mysqli_fetch_array($result)){
			$date = $row['datum_vrijeme_polaska'];
			$date = date('d.m.Y H:i', strtotime($date));
			$id = $row[0];
			echo "<tr><td>$date</td>";
			$car_id = $row['vozilo_id'];
			$Q2 = "SELECT oznaka FROM vozilo WHERE vozilo_id = '$car_id'";
			$result2 = executeQ($conn, $Q2);

			while ($row2 = mysqli_fetch_array($result2)) {
				echo "<td>" . $row2[0] . "</td>";
			}
			
			if ($row['status'] == 0) {
				echo "<td>Čeka se prihvaćanje rezervacije</td></tr>";
			}elseif($row['status'] == 1){
			echo "<td>Rezervacija prihvaćena.</td></tr>";
			}elseif($row['status'] == 2){
			echo "<td>Rezervacija odbijena.</td></tr>";
			}


		}
		echo "</table>";
		echo '</div>';
}

?>
