<?php 
include "header.php";
$conn=dbConn();



if(isset($_SESSION['username']) && $_SESSION['user_type'] == 0){
	$user_id = $_SESSION['user_id'];
	$Q = "SELECT * FROM korisnik";
	$result = executeQ($conn, $Q);

	echo "<div>";
	echo "<table style=' text-align-last: center;'>";
	echo "<caption><h2> Popis korisnika </h2></caption>";
	echo "<thead><tr>
		<th>Korisničko ime</th>
		<th>Ime</th>
		<th>Prezime</th>
		<th>Tip korisnika</th>
		<th>E-mail</th>
		<th>Lozinka</th>
		<th>Slika</th>";
	echo "</tr></thead>";
	
	while ($row = mysqli_fetch_array($result)) {
			$id = $row['korisnik_id'];
			
			echo "<tr>";
			echo "<td>{$row['korisnicko_ime']}</td>";
           	echo "<td>{$row['ime']}</td>";
           	echo "<td>{$row['prezime']}</td>";
           	echo "<td>";if ($row['tip_id'] == 0) {
           		echo "Administrator";
           	}elseif ($row['tip_id'] == 1) {
           		echo "Moderator";
           	}elseif ($row['tip_id'] == 2) {
           		echo "Korisnik";
           	}; echo "</td>";
           	echo "<td>{$row['email']}</td>";
           	echo "<td>{$row['lozinka']}</td>";
           	echo "<td><img width='50px' height='60px' src='{$row['slika']}'/>";
           	echo "<td><a class='link' href='admin-update.php?user=$id'>UREDI</a></td>";
			echo "</tr>";
	}
	echo "</table>";
	 echo "</div>";

}
?>