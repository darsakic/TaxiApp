DROP USER 'iwa_2017'@'localhost';
DROP SCHEMA IF EXISTS `iwa_2017_kz_projekt`;